export type UserRole = 'admin' | 'staff';

export interface UserPermissions {
  canAddReceipt: boolean;
  canDeleteTransactions: boolean;
  canEditProducts: boolean;
}

export interface User {
  id: string;
  username: string;
  fullName: string;
  role: UserRole;
  passwordHash: string;
  initialPassword: string; // برای ریست پسورد به رمز اولی
  passwordResetRequested: boolean; // آیا درخواست ریست داده است؟
  permissions?: UserPermissions; // صلاحیت‌های کارمند
}

export interface FabricType {
  id: string;
  name: string;
}

export interface Product {
  id: string;
  fabricTypeId: string;
  fabricName: string;
  color: string;
  numberOfRolls: number; // تعداد توپ
  metersPerRoll: number; // متراژ هر توپ
  totalMeters: number; // متراژ کل اولیه
  remainingMeters: number; // متراژ باقی‌مانده
  totalPurchasePrice: number; // قیمت خرید کل توپ‌ها
  purchasePricePerMeter: number; // قیمت محاسبه‌شده برای هر متر
  createdAt: string;
}

export interface SaleItem {
  productId: string;
  fabricName: string;
  color: string;
  metersSold: number;
  salePricePerMeter: number;
  totalSalePrice: number;
}

export interface Sale {
  id: string;
  customerName: string;
  items: SaleItem[];
  totalAmount: number;
  paidAmount: number;
  discount: number;
  staffId: string;
  staffName: string;
  createdAt: string;
}

export interface Expense {
  id: string;
  description: string;
  amount: number;
  category: string;
  createdAt: string;
}

export interface Withdrawal {
  id: string;
  personName: string; // پدر، برادر، کارمند و غیره
  amount: number;
  description: string;
  createdAt: string;
}

export interface ShopSettings {
  shopName: string;
  address: string;
  phone: string;
  theme: 'violet' | 'emerald' | 'gold' | 'rose' | 'ocean' | 'dark';
}
