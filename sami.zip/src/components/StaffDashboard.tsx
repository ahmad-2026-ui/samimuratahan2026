import React, { useState } from 'react';
import { Product, Sale, SaleItem, ShopSettings, User } from '../types';
import { ShoppingBag, Search, Plus, Trash2, Printer } from 'lucide-react';
import { InvoiceModal } from './InvoiceModal';

interface StaffDashboardProps {
  products: Product[];
  sales: Sale[];
  currentStaffId: string;
  settings: ShopSettings;
  users: User[];
  onAddSale: (sale: Omit<Sale, 'id' | 'createdAt' | 'staffId' | 'staffName'>) => void;
  onDeleteSale?: (saleId: string) => void; // برای صلاحیت دارها
}

export const StaffDashboard: React.FC<StaffDashboardProps> = ({
  products, sales, currentStaffId, settings, users, onAddSale, onDeleteSale
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [cartItems, setCartItems] = useState<SaleItem[]>([]);
  const [discount, setDiscount] = useState(0);
  const [paidAmount, setPaidAmount] = useState(0);

  const [selectedProductId, setSelectedProductId] = useState('');
  const [metersToSell, setMetersToSell] = useState(0);
  const [customPricePerMeter, setCustomPricePerMeter] = useState(0);

  const [activeInvoice, setActiveInvoice] = useState<Sale | null>(null);

  const currentUser = users.find(u => u.id === currentStaffId);
  const permissions = currentUser?.permissions || { canAddReceipt: true, canDeleteTransactions: false, canEditProducts: false };

  const getThemeClasses = () => {
    switch (settings.theme) {
      case 'emerald': return { primary: 'bg-emerald-600 hover:bg-emerald-700 text-white', text: 'text-emerald-600', border: 'border-emerald-200', btn: 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700' };
      case 'gold': return { primary: 'bg-amber-600 hover:bg-amber-700 text-white', text: 'text-amber-600', border: 'border-amber-200', btn: 'bg-amber-50 hover:bg-amber-100 text-amber-700' };
      case 'rose': return { primary: 'bg-rose-600 hover:bg-rose-700 text-white', text: 'text-rose-600', border: 'border-rose-200', btn: 'bg-rose-50 hover:bg-rose-100 text-rose-700' };
      case 'ocean': return { primary: 'bg-sky-600 hover:bg-sky-700 text-white', text: 'text-sky-600', border: 'border-sky-200', btn: 'bg-sky-50 hover:bg-sky-100 text-sky-700' };
      case 'dark': return { primary: 'bg-slate-800 hover:bg-slate-700 text-white', text: 'text-slate-800', border: 'border-slate-300', btn: 'bg-slate-100 hover:bg-slate-200 text-slate-800' };
      default: return { primary: 'bg-indigo-600 hover:bg-indigo-700 text-white', text: 'text-indigo-600', border: 'border-indigo-200', btn: 'bg-indigo-50 hover:bg-indigo-100 text-indigo-700' };
    }
  };

  const themeStyle = getThemeClasses();

  const filteredProducts = products.filter(p =>
    p.fabricName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.color.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddToCart = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductId || metersToSell <= 0 || customPricePerMeter <= 0) return;

    const product = products.find(p => p.id === selectedProductId);
    if (!product) return;

    if (metersToSell > product.remainingMeters) {
      alert('مقدار متراژ انتخابی بیشتر از موجودی انبار است!');
      return;
    }

    const existingIndex = cartItems.findIndex(item => item.productId === selectedProductId);
    if (existingIndex > -1) {
      alert('این محصول از قبل در سبد خرید موجود است. ابتدا آن را حذف کنید.');
      return;
    }

    const newItem: SaleItem = {
      productId: product.id,
      fabricName: product.fabricName,
      color: product.color,
      metersSold: metersToSell,
      salePricePerMeter: customPricePerMeter,
      totalSalePrice: metersToSell * customPricePerMeter
    };

    setCartItems([...cartItems, newItem]);
    setSelectedProductId('');
    setMetersToSell(0);
    setCustomPricePerMeter(0);
  };

  const handleRemoveFromCart = (productId: string) => {
    setCartItems(cartItems.filter(item => item.productId !== productId));
  };

  const totalCartPrice = cartItems.reduce((sum, item) => sum + item.totalSalePrice, 0);
  const finalPayable = Math.max(0, totalCartPrice - discount);

  const handleFinalCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    if (!permissions.canAddReceipt) {
      alert('شما اجازه ثبت فاکتور را ندارید!');
      return;
    }
    if (cartItems.length === 0) return;

    onAddSale({
      customerName,
      items: cartItems,
      totalAmount: finalPayable,
      paidAmount: paidAmount || finalPayable,
      discount: discount,
    });

    setCartItems([]);
    setCustomerName('');
    setDiscount(0);
    setPaidAmount(0);
  };

  // متر‌های پیش‌فرض
  const defaultMeters = [1, 2, 3, 4, 5, 10, 15, 20];

  return (
    <div className="p-6 max-w-7xl mx-auto font-vazir" dir="rtl">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* صدور فاکتور */}
        <div className="lg:col-span-1 bg-white p-6 rounded-2xl shadow-sm border flex flex-col h-fit">
          <h3 className={`text-lg font-bold mb-4 flex items-center gap-2 ${themeStyle.text}`}>
            <ShoppingBag />
            فروش و فاکتور
          </h3>

          <form onSubmit={handleAddToCart} className="space-y-4 mb-6 border-b pb-4 text-sm">
            <div>
              <label className="block mb-1 font-bold text-slate-600">انتخاب پارچه</label>
              <select
                className="w-full px-3 py-2 border rounded-lg text-right focus:outline-none"
                value={selectedProductId}
                onChange={(e) => {
                  setSelectedProductId(e.target.value);
                  const prod = products.find(p => p.id === e.target.value);
                  if (prod) {
                    setCustomPricePerMeter(prod.purchasePricePerMeter * 1.2);
                  }
                }}
                required
              >
                <option value="">انتخاب از انبار...</option>
                {products.filter(p => p.remainingMeters > 0).map(p => (
                  <option key={p.id} value={p.id}>
                    {p.fabricName} (رنگ: {p.color}) - موجود: {p.remainingMeters} م
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block mb-2 font-bold text-slate-600">انتخاب متراژ (دستی یا آماده)</label>
              <div className="grid grid-cols-4 gap-2 mb-2">
                {defaultMeters.map(meter => (
                  <button
                    type="button"
                    key={meter}
                    onClick={() => setMetersToSell(meter)}
                    className={`p-2 text-xs font-bold rounded-lg border transition ${metersToSell === meter ? `${themeStyle.primary}` : `${themeStyle.btn} border-slate-200`}`}
                  >
                    {meter} متر
                  </button>
                ))}
              </div>
              <div className="flex gap-2 items-center mt-3">
                <input
                  type="number"
                  step="0.1"
                  placeholder="وارد کردن متراژ دلخواه..."
                  className="w-full px-3 py-2 border rounded-lg text-center"
                  value={metersToSell || ''}
                  onChange={(e) => setMetersToSell(Math.max(0, parseFloat(e.target.value)))}
                  required
                />
              </div>
            </div>

            <div>
              <label className="block mb-1 font-bold text-slate-600">قیمت فروش هر متر (توافقی)</label>
              <input type="number" className="w-full px-3 py-2 border rounded-lg text-center font-bold text-green-600" value={customPricePerMeter || ''} onChange={(e) => setCustomPricePerMeter(Math.max(0, parseFloat(e.target.value)))} required />
            </div>

            <button type="submit" className={`w-full ${themeStyle.primary} font-bold py-2.5 rounded-lg flex items-center justify-center gap-1 transition shadow`}>
              <Plus className="w-4 h-4" /> افزودن به سبد فاکتور
            </button>
          </form>

          {cartItems.length > 0 && (
            <div className="flex-1">
              <h4 className="font-bold text-sm text-slate-700 mb-2">لیست اقلام خرید:</h4>
              <div className="divide-y divide-slate-100 text-xs">
                {cartItems.map((item, index) => (
                  <div key={index} className="py-2 flex justify-between items-center">
                    <div>
                      <p className="font-bold">{item.fabricName} (<span className="text-slate-400 font-normal">رنگ: {item.color}</span>)</p>
                      <p className="text-slate-500">{item.metersSold} متر × {item.salePricePerMeter} افغانی</p>
                    </div>
                    <div className="flex items-center gap-2 font-bold">
                      <span className={themeStyle.text}>{item.totalSalePrice.toLocaleString()}</span>
                      <button type="button" onClick={() => handleRemoveFromCart(item.productId)} className="text-red-500 hover:text-red-700 p-1"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </div>
                ))}
              </div>

              <form onSubmit={handleFinalCheckout} className="mt-4 pt-4 border-t border-slate-200 space-y-3 text-sm">
                <input type="text" className="w-full px-3 py-1.5 border rounded-lg focus:outline-none" placeholder="نام مشتری" value={customerName} onChange={(e) => setCustomerName(e.target.value)} />
                <div className="grid grid-cols-2 gap-2">
                  <input type="number" placeholder="تخفیف" className="w-full px-3 py-1.5 border rounded-lg text-center" value={discount || ''} onChange={(e) => setDiscount(Math.max(0, parseFloat(e.target.value)))} />
                  <input type="number" placeholder="مبلغ پرداخت" className="w-full px-3 py-1.5 border rounded-lg text-center text-green-600 bg-green-50" value={paidAmount || ''} onChange={(e) => setPaidAmount(Math.max(0, parseFloat(e.target.value)))} />
                </div>
                <button type="submit" disabled={!permissions.canAddReceipt} className={`w-full font-bold py-2.5 rounded-xl transition ${permissions.canAddReceipt ? 'bg-green-600 hover:bg-green-700 text-white' : 'bg-slate-300 text-slate-500 cursor-not-allowed'}`}>
                  ثبت و نمایش فاکتور نهایی
                </button>
              </form>
            </div>
          )}
        </div>

        {/* موجودی زنده */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white p-4 rounded-2xl border flex items-center gap-3">
            <Search className="w-5 h-5 text-slate-400" />
            <input type="text" className="flex-1 text-sm bg-transparent border-0 focus:outline-none" placeholder="جستجوی سریع کالا..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredProducts.map(p => (
              <div key={p.id} className="bg-white p-4 rounded-xl border flex flex-col justify-between hover:shadow transition">
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-bold text-slate-800 text-lg">{p.fabricName}</h4>
                    <span className={`text-xs px-2.5 py-1 rounded-full font-bold bg-slate-100 ${themeStyle.text}`}>رنگ: {p.color}</span>
                  </div>
                  <p className={`text-2xl font-black mt-1 ${p.remainingMeters <= 20 ? 'text-red-500' : 'text-slate-800'}`}>{p.remainingMeters} متر</p>
                </div>
                {p.remainingMeters <= 20 && (
                  <div className="text-xs bg-red-50 text-red-600 p-2 rounded-lg font-bold mt-2 animate-pulse">
                    ⚠️ هشدار: متراژ کمتر از ۲۰ متر است.
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* فاکتورها */}
          <div className="bg-white p-6 rounded-2xl border overflow-x-auto">
            <h3 className="text-lg font-bold mb-4">فاکتورهای اخیر شما</h3>
            <table className="w-full text-right divide-y divide-slate-100 text-sm">
              <thead className="bg-slate-50 font-bold text-slate-600">
                <tr><th className="p-2">کد فاکتور</th><th className="p-2">مشتری</th><th className="p-2">مبلغ نهایی</th><th className="p-2">عملیات</th></tr>
              </thead>
              <tbody>
                {sales.filter(s => s.staffId === currentStaffId).map(s => (
                  <tr key={s.id} className="border-b">
                    <td className="p-2 font-bold">{s.id.slice(-6).toUpperCase()}</td>
                    <td className="p-2">{s.customerName || 'مشتری متفرقه'}</td>
                    <td className="p-2 text-green-600 font-bold font-mono">{s.totalAmount.toLocaleString()}</td>
                    <td className="p-2 flex gap-2">
                      <button onClick={() => setActiveInvoice(s)} className={`text-xs font-bold border rounded px-2.5 py-1 flex items-center gap-1 ${themeStyle.text}`}><Printer className="w-3.5 h-3.5" /> فاکتور</button>
                      {permissions.canDeleteTransactions && onDeleteSale && (
                        <button onClick={() => { if (confirm('آیا مطمئن هستید؟')) onDeleteSale(s.id); }} className="text-red-500 hover:bg-red-50 p-1.5 rounded"><Trash2 className="w-4 h-4" /></button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {activeInvoice && <InvoiceModal sale={activeInvoice} onClose={() => setActiveInvoice(null)} settings={settings} />}
    </div>
  );
};
