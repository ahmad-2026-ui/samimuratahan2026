import React from 'react';
import { Sale, ShopSettings } from '../types';
import { Printer, X } from 'lucide-react';

interface InvoiceModalProps {
  sale: Sale;
  onClose: () => void;
  settings: ShopSettings;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({ sale, onClose, settings }) => {
  const handlePrint = () => {
    window.print();
  };

  const getThemeColor = () => {
    switch (settings.theme) {
      case 'emerald': return 'text-emerald-600 bg-emerald-50';
      case 'gold': return 'text-amber-600 bg-amber-50';
      case 'rose': return 'text-rose-600 bg-rose-50';
      case 'ocean': return 'text-sky-600 bg-sky-50';
      case 'dark': return 'text-slate-800 bg-slate-100';
      default: return 'text-indigo-600 bg-indigo-50';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 font-vazir p-4 backdrop-blur-sm print:bg-white print:p-0 print:static print:block">
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #invoice-print-area, #invoice-print-area * {
            visibility: visible;
          }
          #invoice-print-area {
            position: absolute;
            left: 0;
            top: 0;
            width: 80mm; /* عرض فیش استاندارد پرینتر حرارتی */
            padding: 5px;
            font-size: 11px;
            line-height: 1.2;
            color: #000;
          }
          .print-header {
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 4px;
            text-align: center;
          }
          .print-divider {
            border-bottom: 1px dashed #000;
            margin: 6px 0;
          }
          table {
            width: 100%;
            font-size: 10px;
          }
          th, td {
            padding: 3px 2px !important;
          }
        }
      `}</style>
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh] print:shadow-none print:max-h-full print:w-full">
        <div className="flex justify-between items-center bg-slate-900 text-white px-6 py-4 print:hidden">
          <h3 className="text-lg font-bold">چاپ و مشاهده فاکتور</h3>
          <button onClick={onClose} className="p-1 hover:bg-slate-800 rounded-lg">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Invoice Content */}
        <div className="p-8 flex-1 overflow-y-auto print:p-1 print:overflow-visible" id="invoice-print-area">
          <div className="border-b-2 border-slate-100 pb-6 mb-6 flex justify-between items-start print:pb-2 print:mb-2 print:border-b-black/30">
            <div>
              <h1 className="text-2xl font-black text-indigo-600 mb-1 print:text-lg print:text-black">{settings.shopName}</h1>
              <p className="text-slate-500 text-sm font-medium print:text-[10px] print:text-black">{settings.address} | تلفن: {settings.phone}</p>
            </div>
            <div className="text-left" dir="ltr">
              <p className="text-sm font-bold text-slate-800 print:text-[10px] print:text-black">کد: {sale.id.slice(-6).toUpperCase()}</p>
              <p className="text-sm text-slate-500 mt-1 print:text-[10px] print:text-black">{new Date(sale.createdAt).toLocaleDateString('fa-IR')}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-6 text-sm text-slate-700 border border-slate-100 p-4 rounded-xl bg-slate-50 print:gap-1 print:p-1 print:mb-2 print:rounded-none print:bg-white print:border-dashed">
            <div>
              <p className="font-bold mb-1">اطلاعات خریدار:</p>
              <p>نام مشتری: {sale.customerName || 'عمومی'}</p>
            </div>
            <div className="text-left" dir="rtl">
              <p className="font-bold mb-1">مسئول فروش:</p>
              <p>{sale.staffName}</p>
            </div>
          </div>

          <table className="w-full text-right mb-6 border-collapse print:mb-2">
            <thead>
              <tr className={`border-b font-bold text-sm ${getThemeColor()} print:bg-slate-100 print:text-black print:text-[10px]`}>
                <th className="py-3 px-4 print:py-1 print:px-1">نوع پارچه</th>
                <th className="py-3 px-4 print:py-1 print:px-1">رنگ</th>
                <th className="py-3 px-4 text-center print:py-1 print:px-1">متراژ</th>
                <th className="py-3 px-4 text-center print:py-1 print:px-1">فی</th>
                <th className="py-3 px-4 text-center print:py-1 print:px-1">مجموع</th>
              </tr>
            </thead>
            <tbody className="text-slate-700 divide-y divide-slate-100 print:divide-dashed print:text-[10px]">
              {sale.items.map((item, index) => (
                <tr key={index} className="text-sm">
                  <td className="py-3 px-4 font-bold">{item.fabricName}</td>
                  <td className="py-3 px-4">{item.color}</td>
                  <td className="py-3 px-4 text-center">{item.metersSold} متر</td>
                  <td className="py-3 px-4 text-center">{item.salePricePerMeter.toLocaleString()} افغانی</td>
                  <td className="py-3 px-4 font-bold text-indigo-600 text-center">
                    {item.totalSalePrice.toLocaleString()} افغانی
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="border-t border-dashed border-slate-400 pt-3 flex flex-col items-end text-slate-800 font-bold gap-1 print:pt-1 print:gap-1 print:text-[10px]">
            <div className="flex gap-4">
              <span className="text-slate-500 font-medium print:text-black">مجموع کل:</span>
              <span>{(sale.totalAmount + sale.discount).toLocaleString()} افغانی</span>
            </div>
            {sale.discount > 0 && (
              <div className="flex gap-4 text-red-600 print:text-black">
                <span className="font-medium">تخفیف:</span>
                <span>-{sale.discount.toLocaleString()} افغانی</span>
              </div>
            )}
            <div className="flex gap-4 text-lg text-indigo-600 border-t border-indigo-50 pt-2 mt-1 print:text-xs print:text-black print:border-black/20">
              <span>قابل پرداخت:</span>
              <span>{sale.totalAmount.toLocaleString()} افغانی</span>
            </div>
            <div className="flex gap-4 text-sm text-green-600 print:text-[10px] print:text-black">
              <span className="font-medium">پرداخت شده:</span>
              <span>{sale.paidAmount.toLocaleString()} افغانی</span>
            </div>
          </div>

          <div className="mt-12 text-center text-xs text-slate-400 border-t border-slate-100 pt-4">
            از خرید و اعتماد شما متشکریم!
          </div>
        </div>

        {/* Buttons */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end gap-3 print:hidden">
          <button onClick={onClose} className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg transition">بستن</button>
          <button onClick={handlePrint} className="flex items-center gap-2 px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold shadow-md transition">
            <Printer className="w-5 h-5" /> چاپ فاکتور
          </button>
        </div>
      </div>
    </div>
  );
};
