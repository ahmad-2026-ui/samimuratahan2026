import React, { useState } from 'react';
import { Product, Sale, Expense, Withdrawal, User, FabricType, ShopSettings, SaleItem, UserPermissions } from '../types';
import { 
  Package, DollarSign, Users, ShoppingCart, 
  Wallet, TrendingUp, AlertTriangle, Trash2, ArrowRightLeft, Settings, Database, ShieldAlert, Plus, Printer, Search, ShoppingBag
} from 'lucide-react';
import { InvoiceModal } from './InvoiceModal';

interface AdminDashboardProps {
  products: Product[];
  sales: Sale[];
  expenses: Expense[];
  withdrawals: Withdrawal[];
  users: User[];
  fabricTypes: FabricType[];
  settings: ShopSettings;
  onAddProduct: (product: Omit<Product, 'id' | 'createdAt' | 'remainingMeters' | 'purchasePricePerMeter'>) => void;
  onDeleteProduct: (id: string) => void;
  onAddExpense: (expense: Omit<Expense, 'id' | 'createdAt'>) => void;
  onDeleteExpense: (id: string) => void;
  onAddWithdrawal: (withdrawal: Omit<Withdrawal, 'id' | 'createdAt'>) => void;
  onDeleteWithdrawal: (id: string) => void;
  onAddFabricType: (name: string) => void;
  onResetPassword: (userId: string) => void;
  onDenyResetPassword: (userId: string) => void;
  onUpdateSettings: (newSettings: ShopSettings) => void;
  onCreateUser: (fullName: string, username: string, role: 'admin' | 'staff', initialPass: string, permissions: UserPermissions) => void;
  onUpdateUserPermissions: (userId: string, permissions: UserPermissions) => void;
  onResetDatabase: () => void;
  onAddSale: (sale: Omit<Sale, 'id' | 'createdAt' | 'staffId' | 'staffName'>) => void;
  onDeleteSale: (id: string) => void;
  onDeleteUser: (id: string) => void;
  onUpdateUser: (id: string, fullName: string, username: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  products, sales, expenses, withdrawals, users, fabricTypes, settings,
  onAddProduct, onDeleteProduct, onAddExpense, onDeleteExpense,
  onAddWithdrawal, onDeleteWithdrawal, onAddFabricType, onResetPassword, onDenyResetPassword,
  onUpdateSettings, onCreateUser, onUpdateUserPermissions, onResetDatabase, onAddSale, onDeleteSale,
  onDeleteUser, onUpdateUser
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'sales' | 'products' | 'expenses' | 'withdrawals' | 'users' | 'settings'>('overview');

  // Sales form
  const [searchTerm, setSearchTerm] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [cartItems, setCartItems] = useState<SaleItem[]>([]);
  const [discount, setDiscount] = useState(0);
  const [paidAmount, setPaidAmount] = useState(0);
  const [selectedProductId, setSelectedProductId] = useState('');
  const [metersToSell, setMetersToSell] = useState(0);
  const [customPricePerMeter, setCustomPricePerMeter] = useState(0);
  const [activeInvoice, setActiveInvoice] = useState<Sale | null>(null);

  // Product form
  const [fabricTypeId, setFabricTypeId] = useState('');
  const [color, setColor] = useState('');
  const [numberOfRolls, setNumberOfRolls] = useState(1);
  const [metersPerRoll, setMetersPerRoll] = useState(0);
  const [totalPurchasePrice, setTotalPurchasePrice] = useState(0);
  const [newFabricName, setNewFabricName] = useState('');

  // Expense form
  const [expenseDesc, setExpenseDesc] = useState('');
  const [expenseAmount, setExpenseAmount] = useState(0);

  // Withdrawal form
  const [withdrawalPerson, setWithdrawalPerson] = useState('');
  const [withdrawalAmount, setWithdrawalAmount] = useState(0);
  const [withdrawalDesc, setWithdrawalDesc] = useState('');

  // User creation form
  const [newFullName, setNewFullName] = useState('');
  const [newUsername, setNewUsername] = useState('');
  const [newRole, setNewRole] = useState<'admin' | 'staff'>('staff');
  const [newPass, setNewPass] = useState('');
  const [permAddReceipt, setPermAddReceipt] = useState(true);
  const [permDelete, setPermDelete] = useState(false);
  const [permEditProduct, setPermEditProduct] = useState(false);

  // User editing states
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [editFullName, setEditFullName] = useState<string>('');
  const [editUsername, setEditUsername] = useState<string>('');

  // Settings form
  const [shopName, setShopName] = useState(settings.shopName);
  const [shopAddress, setShopAddress] = useState(settings.address);
  const [shopPhone, setShopPhone] = useState(settings.phone);
  const [shopTheme, setShopTheme] = useState(settings.theme);

  const getThemeClasses = () => {
    switch (settings.theme) {
      case 'emerald': return { primary: 'bg-emerald-600 hover:bg-emerald-700 text-white', text: 'text-emerald-600', border: 'border-emerald-600', light: 'bg-emerald-50', btn: 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700' };
      case 'gold': return { primary: 'bg-amber-600 hover:bg-amber-700 text-white', text: 'text-amber-600', border: 'border-amber-600', light: 'bg-amber-50', btn: 'bg-amber-50 hover:bg-amber-100 text-amber-700' };
      case 'rose': return { primary: 'bg-rose-600 hover:bg-rose-700 text-white', text: 'text-rose-600', border: 'border-rose-600', light: 'bg-rose-50', btn: 'bg-rose-50 hover:bg-rose-100 text-rose-700' };
      case 'ocean': return { primary: 'bg-sky-600 hover:bg-sky-700 text-white', text: 'text-sky-600', border: 'border-sky-600', light: 'bg-sky-50', btn: 'bg-sky-50 hover:bg-sky-100 text-sky-700' };
      case 'dark': return { primary: 'bg-slate-800 hover:bg-slate-700 text-white', text: 'text-slate-800', border: 'border-slate-800', light: 'bg-slate-100', btn: 'bg-slate-100 hover:bg-slate-200 text-slate-800' };
      default: return { primary: 'bg-indigo-600 hover:bg-indigo-700 text-white', text: 'text-indigo-600', border: 'border-indigo-600', light: 'bg-indigo-50', btn: 'bg-indigo-50 hover:bg-indigo-100 text-indigo-700' };
    }
  };

  const themeStyle = getThemeClasses();

  const totalSales = sales.reduce((sum, s) => sum + s.totalAmount, 0);
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const totalWithdrawals = withdrawals.reduce((sum, w) => sum + w.amount, 0);

  const totalProfit = sales.reduce((sumProfit, sale) => {
    const saleItemsProfit = sale.items.reduce((itemProfit, item) => {
      const prod = products.find(p => p.id === item.productId);
      const costPerMeter = prod ? prod.purchasePricePerMeter : 0;
      const itemCost = item.metersSold * costPerMeter;
      return itemProfit + (item.totalSalePrice - itemCost);
    }, 0);
    return sumProfit + saleItemsProfit;
  }, 0) - totalExpenses;

  // توابع فرم‌ها
  const handleProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fabricTypeId || !color || metersPerRoll <= 0 || totalPurchasePrice <= 0) return;
    const fabric = fabricTypes.find(f => f.id === fabricTypeId);
    onAddProduct({
      fabricTypeId,
      fabricName: fabric ? fabric.name : '',
      color,
      numberOfRolls,
      metersPerRoll,
      totalMeters: numberOfRolls * metersPerRoll,
      totalPurchasePrice,
    });
    setFabricTypeId('');
    setColor('');
    setNumberOfRolls(1);
    setMetersPerRoll(0);
    setTotalPurchasePrice(0);
  };

  const handleExpenseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expenseDesc.trim() || expenseAmount <= 0) return;
    onAddExpense({ description: expenseDesc, amount: expenseAmount, category: 'عمومی' });
    setExpenseDesc('');
    setExpenseAmount(0);
  };

  const handleWithdrawalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!withdrawalPerson.trim() || withdrawalAmount <= 0) return;
    onAddWithdrawal({ personName: withdrawalPerson, amount: withdrawalAmount, description: withdrawalDesc });
    setWithdrawalPerson('');
    setWithdrawalAmount(0);
    setWithdrawalDesc('');
  };

  const handleCreateUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFullName.trim() || !newUsername.trim() || !newPass.trim()) return;
    onCreateUser(newFullName, newUsername.toLowerCase(), newRole, newPass, {
      canAddReceipt: permAddReceipt,
      canDeleteTransactions: permDelete,
      canEditProducts: permEditProduct
    });
    setNewFullName('');
    setNewUsername('');
    setNewPass('');
    setPermAddReceipt(true);
    setPermDelete(false);
    setPermEditProduct(false);
    alert('کاربر با موفقیت اضافه شد!');
  };

  const handleSettingsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings({
      shopName,
      address: shopAddress,
      phone: shopPhone,
      theme: shopTheme
    });
    alert('تنظیمات فروشگاه ذخیره شد.');
  };

  const handleBackupDownload = () => {
    const data = {
      users: localStorage.getItem('cloth_users'),
      fabrics: localStorage.getItem('cloth_fabrics'),
      products: localStorage.getItem('cloth_products'),
      sales: localStorage.getItem('cloth_sales'),
      expenses: localStorage.getItem('cloth_expenses'),
      withdrawals: localStorage.getItem('cloth_withdrawals'),
      settings: localStorage.getItem('cloth_settings')
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
  };

  const handleBackupUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.users) localStorage.setItem('cloth_users', parsed.users);
        if (parsed.fabrics) localStorage.setItem('cloth_fabrics', parsed.fabrics);
        if (parsed.products) localStorage.setItem('cloth_products', parsed.products);
        if (parsed.sales) localStorage.setItem('cloth_sales', parsed.sales);
        if (parsed.expenses) localStorage.setItem('cloth_expenses', parsed.expenses);
        if (parsed.withdrawals) localStorage.setItem('cloth_withdrawals', parsed.withdrawals);
        if (parsed.settings) localStorage.setItem('cloth_settings', parsed.settings);

        alert('اطلاعات بکاپ با موفقیت بازیابی شد.');
        window.location.reload();
      } catch (err) {
        alert('فایل وارد شده معتبر نیست!');
      }
    };
    reader.readAsText(file);
  };

  // عملیات فروش (Admin Sales)
  const handleAddToCart = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductId || metersToSell <= 0 || customPricePerMeter <= 0) return;

    const product = products.find(p => p.id === selectedProductId);
    if (!product) return;

    if (metersToSell > product.remainingMeters) {
      alert('مقدار متراژ انتخابی بیشتر از موجودی انبار است!');
      return;
    }

    const newItem: SaleItem = {
      productId: product.id,
      fabricName: product.fabricName,
      color: product.color,
      metersSold: metersToSell,
      salePricePerMeter: customPricePerMeter,
      totalSalePrice: metersToSell * customPricePerMeter
    };

    setCartItems([...cartItems, newItem]);
    setSelectedProductId('');
    setMetersToSell(0);
    setCustomPricePerMeter(0);
  };

  const totalCartPrice = cartItems.reduce((sum, item) => sum + item.totalSalePrice, 0);
  const finalPayable = Math.max(0, totalCartPrice - discount);

  const handleFinalCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    if (cartItems.length === 0) return;

    onAddSale({
      customerName,
      items: cartItems,
      totalAmount: finalPayable,
      paidAmount: paidAmount || finalPayable,
      discount: discount,
    });

    setCartItems([]);
    setCustomerName('');
    setDiscount(0);
    setPaidAmount(0);
  };

  const defaultMeters = [1, 2, 3, 4, 5, 10, 15, 20];
  const filteredProducts = products.filter(p =>
    p.fabricName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.color.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 max-w-7xl mx-auto font-vazir" dir="rtl">
      {/* Tabs */}
      <div className="flex border-b border-slate-200 mb-6 overflow-x-auto gap-2">
        <button onClick={() => setActiveTab('overview')} className={`flex items-center gap-2 px-4 py-3 border-b-2 text-sm font-bold transition ${activeTab === 'overview' ? `${themeStyle.border} ${themeStyle.text}` : 'border-transparent text-slate-500 hover:text-indigo-600'}`}><TrendingUp className="w-5 h-5" /> خلاصه کارکرد</button>
        <button onClick={() => setActiveTab('sales')} className={`flex items-center gap-2 px-4 py-3 border-b-2 text-sm font-bold transition ${activeTab === 'sales' ? `${themeStyle.border} ${themeStyle.text}` : 'border-transparent text-slate-500 hover:text-indigo-600'}`}><ShoppingCart className="w-5 h-5" /> صدور فاکتور</button>
        <button onClick={() => setActiveTab('products')} className={`flex items-center gap-2 px-4 py-3 border-b-2 text-sm font-bold transition ${activeTab === 'products' ? `${themeStyle.border} ${themeStyle.text}` : 'border-transparent text-slate-500 hover:text-indigo-600'}`}><Package className="w-5 h-5" /> انبار پارچه‌ها</button>
        <button onClick={() => setActiveTab('expenses')} className={`flex items-center gap-2 px-4 py-3 border-b-2 text-sm font-bold transition ${activeTab === 'expenses' ? `${themeStyle.border} ${themeStyle.text}` : 'border-transparent text-slate-500 hover:text-indigo-600'}`}><DollarSign className="w-5 h-5" /> مصارف</button>
        <button onClick={() => setActiveTab('withdrawals')} className={`flex items-center gap-2 px-4 py-3 border-b-2 text-sm font-bold transition ${activeTab === 'withdrawals' ? `${themeStyle.border} ${themeStyle.text}` : 'border-transparent text-slate-500 hover:text-indigo-600'}`}><ArrowRightLeft className="w-5 h-5" /> برداشت نقدی</button>
        <button onClick={() => setActiveTab('users')} className={`flex items-center gap-2 px-4 py-3 border-b-2 text-sm font-bold transition ${activeTab === 'users' ? `${themeStyle.border} ${themeStyle.text}` : 'border-transparent text-slate-500 hover:text-indigo-600'}`}><Users className="w-5 h-5" /> کارمندان</button>
        <button onClick={() => setActiveTab('settings')} className={`flex items-center gap-2 px-4 py-3 border-b-2 text-sm font-bold transition ${activeTab === 'settings' ? `${themeStyle.border} ${themeStyle.text}` : 'border-transparent text-slate-500 hover:text-indigo-600'}`}><Settings className="w-5 h-5" /> تنظیمات</button>
      </div>

      {/* Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-2xl border flex items-center justify-between">
              <div><p className="text-slate-500 text-sm font-bold">مجموع فروش</p><h3 className={`text-2xl font-black mt-2 ${themeStyle.text}`}>{totalSales.toLocaleString()} افغانی</h3></div>
              <div className={`${themeStyle.light} p-4 rounded-xl ${themeStyle.text}`}><ShoppingCart className="w-6 h-6" /></div>
            </div>
            <div className="bg-white p-6 rounded-2xl border flex items-center justify-between">
              <div><p className="text-slate-500 text-sm font-bold">مجموع مصارف</p><h3 className="text-2xl font-black text-red-500 mt-2">{totalExpenses.toLocaleString()} افغانی</h3></div>
              <div className="bg-red-50 p-4 rounded-xl text-red-600"><Wallet className="w-6 h-6" /></div>
            </div>
            <div className="bg-white p-6 rounded-2xl border flex items-center justify-between">
              <div><p className="text-slate-500 text-sm font-bold">مجموع برداشت</p><h3 className="text-2xl font-black text-orange-500 mt-2">{totalWithdrawals.toLocaleString()} افغانی</h3></div>
              <div className="bg-orange-50 p-4 rounded-xl text-orange-500"><ArrowRightLeft className="w-6 h-6" /></div>
            </div>
            <div className="bg-white p-6 rounded-2xl border flex items-center justify-between">
              <div><p className="text-slate-500 text-sm font-bold">مفاد خالص</p><h3 className={`text-2xl font-black mt-2 ${totalProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>{totalProfit.toLocaleString()} افغانی</h3></div>
              <div className={`p-4 rounded-xl ${totalProfit >= 0 ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'}`}><TrendingUp className="w-6 h-6" /></div>
            </div>
          </div>

          {/* هشدارهای متراژ زیر ۲۰ متر */}
          <div className="bg-white p-6 rounded-2xl border">
            <h3 className="text-lg font-bold mb-4 text-slate-800 flex items-center gap-2"><AlertTriangle className="text-yellow-500 animate-bounce" /> هشدارهای متراژ (کمتر از ۲۰ متر باقی‌مانده)</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {products.filter(p => p.remainingMeters <= 20).map(p => (
                <div key={p.id} className="p-4 border border-yellow-200 bg-yellow-50 rounded-xl flex justify-between items-center">
                  <div><h4 className="font-bold text-slate-800">{p.fabricName}</h4><p className="text-xs text-slate-500 mt-1">رنگ: {p.color}</p></div>
                  <div className="text-left font-bold text-yellow-700">{p.remainingMeters} متر مانده</div>
                </div>
              ))}
              {products.filter(p => p.remainingMeters <= 20).length === 0 && <p className="text-slate-400 text-sm italic">موجودی کافی است و موردی برای هشدار وجود ندارد.</p>}
            </div>
          </div>
        </div>
      )}

      {/* Sales (صدور فاکتور) */}
      {activeTab === 'sales' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 bg-white p-6 rounded-2xl border flex flex-col h-fit">
            <h3 className={`text-lg font-bold mb-4 flex items-center gap-2 ${themeStyle.text}`}><ShoppingBag /> صدور فاکتور (ادمین)</h3>
            <form onSubmit={handleAddToCart} className="space-y-4 mb-6 text-sm">
              <div>
                <label className="block mb-1 font-bold text-slate-600">انتخاب پارچه</label>
                <div className="flex gap-2 items-center border rounded-lg px-2 py-1.5 bg-slate-50 mb-2 text-xs">
                  <Search className="w-4 h-4 text-slate-400" />
                  <input type="text" placeholder="جستجوی سریع..." className="bg-transparent w-full focus:outline-none" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
                </div>
                <select className="w-full px-3 py-2 border rounded-lg text-right" value={selectedProductId} onChange={(e) => { setSelectedProductId(e.target.value); const prod = products.find(p => p.id === e.target.value); if (prod) setCustomPricePerMeter(prod.purchasePricePerMeter * 1.2); }} required>
                  <option value="">انتخاب...</option>
                  {filteredProducts.map(p => <option key={p.id} value={p.id}>{p.fabricName} (رنگ: {p.color}) - موجود: {p.remainingMeters} م</option>)}
                </select>
              </div>

              <div>
                <label className="block mb-2 font-bold text-slate-600">انتخاب متراژ</label>
                <div className="grid grid-cols-4 gap-2">
                  {defaultMeters.map(m => (
                    <button type="button" key={m} onClick={() => setMetersToSell(m)} className={`p-2 text-xs font-bold rounded-lg border transition ${metersToSell === m ? `${themeStyle.primary}` : `${themeStyle.btn} border-slate-200`}`}>{m} متر</button>
                  ))}
                </div>
                <input type="number" step="0.1" placeholder="وارد کردن متراژ دستی..." className="w-full px-3 py-2 border rounded-lg text-center mt-3" value={metersToSell || ''} onChange={(e) => setMetersToSell(Math.max(0, parseFloat(e.target.value)))} required />
              </div>

              <div>
                <label className="block mb-1 font-bold text-slate-600">قیمت فروش هر متر (توافقی)</label>
                <input type="number" className="w-full px-3 py-2 border rounded-lg text-center font-bold text-green-600" value={customPricePerMeter || ''} onChange={(e) => setCustomPricePerMeter(Math.max(0, parseFloat(e.target.value)))} required />
              </div>
              <button type="submit" className={`w-full ${themeStyle.primary} py-2.5 rounded-lg flex items-center justify-center gap-1 font-bold`}><Plus className="w-4 h-4" /> اضافه به سبد خرید</button>
            </form>

            {cartItems.length > 0 && (
              <div className="border-t pt-4">
                <div className="divide-y text-xs mb-4">
                  {cartItems.map((item, i) => (
                    <div key={i} className="py-2 flex justify-between items-center">
                      <div><p className="font-bold">{item.fabricName} ({item.color})</p><p>{item.metersSold} متر × {item.salePricePerMeter}</p></div>
                      <span className={themeStyle.text}>{item.totalSalePrice.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
                <form onSubmit={handleFinalCheckout} className="space-y-3">
                  <input type="text" placeholder="نام مشتری" className="w-full px-3 py-2 border rounded-lg text-sm" value={customerName} onChange={(e) => setCustomerName(e.target.value)} />
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <input type="number" placeholder="تخفیف" className="w-full px-3 py-2 border rounded-lg" value={discount || ''} onChange={(e) => setDiscount(Math.max(0, parseFloat(e.target.value)))} />
                    <input type="number" placeholder="پرداختی" className="w-full px-3 py-2 border rounded-lg" value={paidAmount || ''} onChange={(e) => setPaidAmount(Math.max(0, parseFloat(e.target.value)))} />
                  </div>
                  <button type="submit" className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 rounded-xl">ثبت و دریافت فاکتور</button>
                </form>
              </div>
            )}
          </div>

          <div className="lg:col-span-2 bg-white p-6 rounded-2xl border">
            <h3 className="text-lg font-bold mb-4">تاریخچه فاکتورها</h3>
            <table className="w-full text-right text-sm">
              <thead className="bg-slate-50 font-bold">
                <tr><th>کد</th><th>مشتری</th><th>مبلغ فاکتور</th><th>عملیات</th></tr>
              </thead>
              <tbody>
                {sales.map(s => (
                  <tr key={s.id} className="border-b">
                    <td className="p-2 font-bold">{s.id.slice(-6).toUpperCase()}</td>
                    <td className="p-2">{s.customerName || 'عمومی'}</td>
                    <td className="p-2 text-green-600 font-bold font-mono">{s.totalAmount.toLocaleString()}</td>
                    <td className="p-2 flex gap-2">
                      <button onClick={() => setActiveInvoice(s)} className={`text-xs px-2 py-1 border rounded ${themeStyle.text}`}><Printer className="w-3.5 h-3.5 inline ml-1" /> فاکتور</button>
                      <button onClick={() => onDeleteSale(s.id)} className="text-red-500 hover:bg-red-50 p-1 rounded"><Trash2 className="w-4 h-4" /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Products */}
      {activeTab === 'products' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-2xl border">
              <h3 className="text-lg font-bold mb-4 text-slate-800">تعریف نوع جدید پارچه</h3>
              <form onSubmit={(e) => { e.preventDefault(); if (newFabricName) { onAddFabricType(newFabricName); setNewFabricName(''); } }} className="space-y-3">
                <input type="text" placeholder="نخی، مخمل، کتان..." className="w-full px-3 py-2 border rounded-lg" value={newFabricName} onChange={(e) => setNewFabricName(e.target.value)} />
                <button type="submit" className={`w-full ${themeStyle.primary} py-2 rounded-lg text-sm text-white font-bold`}>ذخیره نوع پارچه</button>
              </form>
            </div>

            <div className="bg-white p-6 rounded-2xl border">
              <h3 className="text-lg font-bold mb-4">خرید و شارژ توپ پارچه</h3>
              <form onSubmit={handleProductSubmit} className="space-y-4 text-sm">
                <div>
                  <label className="block text-slate-600 font-bold mb-1">نوع پارچه</label>
                  <select className="w-full px-3 py-2 border rounded-lg text-right" value={fabricTypeId} onChange={(e) => setFabricTypeId(e.target.value)} required>
                    <option value="">انتخاب نوع...</option>
                    {fabricTypes.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
                  </select>
                </div>
                <div><label className="block text-slate-600 font-bold mb-1">رنگ</label><input type="text" className="w-full px-3 py-2 border rounded-lg" value={color} onChange={(e) => setColor(e.target.value)} required /></div>
                <div className="grid grid-cols-2 gap-2">
                  <div><label className="block text-slate-600 font-bold mb-1">تعداد توپ</label><input type="number" min="1" className="w-full px-3 py-2 border rounded-lg" value={numberOfRolls} onChange={(e) => setNumberOfRolls(parseInt(e.target.value))} required /></div>
                  <div><label className="block text-slate-600 font-bold mb-1">متراژ هر توپ</label><input type="number" min="1" className="w-full px-3 py-2 border rounded-lg" value={metersPerRoll || ''} onChange={(e) => setMetersPerRoll(parseFloat(e.target.value))} required /></div>
                </div>
                <div><label className="block text-slate-600 font-bold mb-1">قیمت کل خرید (افغانی)</label><input type="number" min="1" className="w-full px-3 py-2 border rounded-lg font-bold text-indigo-600" value={totalPurchasePrice || ''} onChange={(e) => setTotalPurchasePrice(parseFloat(e.target.value))} required /></div>
                <button type="submit" className={`w-full ${themeStyle.primary} text-white py-2.5 rounded-lg font-bold`}>ذخیره در انبار</button>
              </form>
            </div>
          </div>

          <div className="lg:col-span-2 bg-white p-6 rounded-2xl border overflow-x-auto">
            <h3 className="text-lg font-bold mb-4">لیست موجودی انبار</h3>
            <table className="w-full text-right text-sm">
              <thead className="bg-slate-50 font-bold">
                <tr><th className="p-3">نوع پارچه</th><th className="p-3">رنگ</th><th className="p-3">توپ‌ها</th><th className="p-3">کل متر</th><th className="p-3">باقی‌مانده</th><th className="p-3">عملیات</th></tr>
              </thead>
              <tbody className="divide-y">
                {products.map(p => (
                  <tr key={p.id}>
                    <td className="p-3 font-bold">{p.fabricName}</td><td className="p-3">{p.color}</td><td className="p-3">{p.numberOfRolls}</td><td className="p-3">{p.totalMeters}</td>
                    <td className={`p-3 font-bold font-mono ${p.remainingMeters <= 20 ? 'text-red-500 animate-pulse' : 'text-slate-800'}`}>{p.remainingMeters} م</td>
                    <td className="p-3"><button onClick={() => onDeleteProduct(p.id)} className="text-red-500 hover:text-red-700"><Trash2 className="w-4 h-4" /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Expenses */}
      {activeTab === 'expenses' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl border h-fit">
            <h3 className="text-lg font-bold mb-4">ثبت هزینه جدید</h3>
            <form onSubmit={handleExpenseSubmit} className="space-y-4">
              <input type="text" placeholder="شرح هزینه..." className="w-full px-3 py-2 border rounded-lg" value={expenseDesc} onChange={(e) => setExpenseDesc(e.target.value)} required />
              <input type="number" placeholder="مبلغ (افغانی)" className="w-full px-3 py-2 border rounded-lg font-bold" value={expenseAmount || ''} onChange={(e) => setExpenseAmount(parseFloat(e.target.value))} required />
              <button type="submit" className={`w-full ${themeStyle.primary} py-2 rounded-lg text-white font-bold`}>ذخیره هزینه</button>
            </form>
          </div>
          <div className="lg:col-span-2 bg-white p-6 rounded-2xl border">
            <h3 className="text-lg font-bold mb-4">گزارش مصارف</h3>
            <table className="w-full text-right text-sm">
              <thead className="bg-slate-50 font-bold"><tr><th className="p-2">توضیحات</th><th className="p-2">مبلغ</th><th className="p-2">عملیات</th></tr></thead>
              <tbody className="divide-y">
                {expenses.map(e => (
                  <tr key={e.id} className="text-slate-700"><td className="p-2 font-medium">{e.description}</td><td className="p-2 font-bold text-red-500 font-mono">{e.amount.toLocaleString()} افغانی</td><td className="p-2"><button onClick={() => onDeleteExpense(e.id)} className="text-red-500"><Trash2 className="w-4 h-4" /></button></td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Withdrawals */}
      {activeTab === 'withdrawals' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl border h-fit">
            <h3 className="text-lg font-bold mb-4">برداشت نقدی (پدر، برادر، کارمند)</h3>
            <form onSubmit={handleWithdrawalSubmit} className="space-y-4 text-sm">
              <input type="text" placeholder="نام برداشت کننده..." className="w-full px-3 py-2 border rounded-lg" value={withdrawalPerson} onChange={(e) => setWithdrawalPerson(e.target.value)} required />
              <input type="number" placeholder="مبلغ برداشت" className="w-full px-3 py-2 border rounded-lg font-bold" value={withdrawalAmount || ''} onChange={(e) => setWithdrawalAmount(parseFloat(e.target.value))} required />
              <textarea placeholder="توضیحات..." className="w-full px-3 py-2 border rounded-lg" value={withdrawalDesc} onChange={(e) => setWithdrawalDesc(e.target.value)}></textarea>
              <button type="submit" className={`w-full ${themeStyle.primary} text-white font-bold py-2 rounded-lg`}>ذخیره و چاپ رسید</button>
            </form>
          </div>
          <div className="lg:col-span-2 bg-white p-6 rounded-2xl border overflow-x-auto">
            <h3 className="text-lg font-bold mb-4">لیست برداشت‌ها</h3>
            <table className="w-full text-right text-sm">
              <thead className="bg-slate-50 font-bold"><tr><th>برداشت کننده</th><th>مبلغ</th><th>توضیحات</th><th>حذف</th></tr></thead>
              <tbody className="divide-y">
                {withdrawals.map(w => (
                  <tr key={w.id} className="border-b"><td className="p-2 font-bold">{w.personName}</td><td className="p-2 font-bold font-mono text-orange-600">{w.amount.toLocaleString()}</td><td className="p-2">{w.description}</td><td className="p-2"><button onClick={() => onDeleteWithdrawal(w.id)} className="text-red-500"><Trash2 className="w-4 h-4" /></button></td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Users */}
      {activeTab === 'users' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-sm">
          <div className="bg-white p-6 rounded-2xl border h-fit">
            <h3 className="text-lg font-bold mb-4">ایجاد حساب کارمند</h3>
            <form onSubmit={handleCreateUserSubmit} className="space-y-4">
              <input type="text" placeholder="نام کامل..." className="w-full px-3 py-2 border rounded-lg" value={newFullName} onChange={(e) => setNewFullName(e.target.value)} required />
              <input type="text" placeholder="نام کاربری (English)" className="w-full px-3 py-2 border rounded-lg text-left font-mono" value={newUsername} onChange={(e) => setNewUsername(e.target.value)} required />
              
              <select className="w-full px-3 py-2 border rounded-lg" value={newRole} onChange={(e) => setNewRole(e.target.value as 'admin' | 'staff')}>
                <option value="staff">کارمند فروش</option>
                <option value="admin">مدیر (ادمین)</option>
              </select>

              <input type="password" placeholder="رمز عبور پیش‌فرض" className="w-full px-3 py-2 border rounded-lg text-left font-mono" value={newPass} onChange={(e) => setNewPass(e.target.value)} required />

              {newRole === 'staff' && (
                <div className="bg-slate-50 p-3 rounded-xl border space-y-2 mt-2">
                  <h4 className="font-bold text-slate-700 mb-1">صلاحیت‌ها و اختیارات کارمند:</h4>
                  <label className="flex items-center gap-2 text-xs">
                    <input type="checkbox" checked={permAddReceipt} onChange={(e) => setPermAddReceipt(e.target.checked)} className="rounded text-indigo-600 focus:ring-0" /> امکان ثبت رسید و فروش
                  </label>
                  <label className="flex items-center gap-2 text-xs">
                    <input type="checkbox" checked={permDelete} onChange={(e) => setPermDelete(e.target.checked)} className="rounded text-indigo-600 focus:ring-0" /> امکان حذف تراکنش‌ها (فاکتورها)
                  </label>
                  <label className="flex items-center gap-2 text-xs">
                    <input type="checkbox" checked={permEditProduct} onChange={(e) => setPermEditProduct(e.target.checked)} className="rounded text-indigo-600 focus:ring-0" /> امکان دستکاری انبار محصولات
                  </label>
                </div>
              )}

              <button type="submit" className={`w-full ${themeStyle.primary} text-white font-bold py-2.5 rounded-lg mt-4 shadow`}>ثبت و ایجاد حساب کاربری</button>
            </form>
          </div>

          <div className="lg:col-span-2 bg-white p-6 rounded-2xl border">
            <h3 className="text-lg font-bold mb-4">لیست کارمندان و وضعیت‌ها</h3>
            <div className="divide-y divide-slate-100">
              {users.map(u => (
                <div key={u.id} className="py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  {editingUserId === u.id ? (
                    <div className="flex-1 flex flex-col sm:flex-row gap-2">
                      <input 
                        type="text" 
                        className="px-2 py-1 border rounded text-sm font-bold flex-1" 
                        value={editFullName} 
                        onChange={(e) => setEditFullName(e.target.value)} 
                        placeholder="نام کامل" 
                      />
                      <input 
                        type="text" 
                        className="px-2 py-1 border rounded text-sm font-mono flex-1 text-left" 
                        value={editUsername} 
                        onChange={(e) => setEditUsername(e.target.value)} 
                        placeholder="نام کاربری" 
                      />
                      <div className="flex gap-1">
                        <button 
                          onClick={() => {
                            if (editFullName.trim() && editUsername.trim()) {
                              onUpdateUser(u.id, editFullName, editUsername.toLowerCase());
                              setEditingUserId(null);
                            }
                          }} 
                          className="bg-green-600 text-white px-3 py-1 rounded text-xs font-bold"
                        >
                          ذخیره
                        </button>
                        <button 
                          onClick={() => setEditingUserId(null)} 
                          className="bg-slate-300 text-slate-700 px-3 py-1 rounded text-xs font-bold"
                        >
                          انصراف
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <span className="font-bold text-slate-800 text-base">{u.fullName}</span>
                      <span className="bg-slate-100 text-slate-600 font-mono px-2 py-0.5 rounded text-xs mx-2">@{u.username}</span>
                      <span className={`px-2 py-0.5 text-xs rounded-lg font-bold ${u.role === 'admin' ? 'bg-indigo-50 text-indigo-600' : 'bg-green-50 text-green-600'}`}>{u.role === 'admin' ? 'مدیر سیستم' : 'کارمند'}</span>
                      
                      {u.role === 'staff' && u.permissions && (
                        <div className="flex flex-wrap gap-2 mt-2">
                          <button 
                            onClick={() => onUpdateUserPermissions(u.id, { ...u.permissions, canAddReceipt: !u.permissions?.canAddReceipt } as UserPermissions)} 
                            className={`text-[10px] px-2 py-0.5 rounded border transition ${u.permissions.canAddReceipt ? 'bg-green-100 border-green-300 text-green-800 font-bold' : 'bg-slate-50 border-slate-200 text-slate-400'}`}
                            title="تغییر دسترسی ثبت فاکتور"
                          >
                            صلاحیت فروش: {u.permissions.canAddReceipt ? 'دارد' : 'ندارد'}
                          </button>
                          <button 
                            onClick={() => onUpdateUserPermissions(u.id, { ...u.permissions, canDeleteTransactions: !u.permissions?.canDeleteTransactions } as UserPermissions)} 
                            className={`text-[10px] px-2 py-0.5 rounded border transition ${u.permissions.canDeleteTransactions ? 'bg-green-100 border-green-300 text-green-800 font-bold' : 'bg-slate-50 border-slate-200 text-slate-400'}`}
                            title="تغییر دسترسی حذف تراکنش"
                          >
                            حذف فاکتور: {u.permissions.canDeleteTransactions ? 'دارد' : 'ندارد'}
                          </button>
                          <button 
                            onClick={() => onUpdateUserPermissions(u.id, { ...u.permissions, canEditProducts: !u.permissions?.canEditProducts } as UserPermissions)} 
                            className={`text-[10px] px-2 py-0.5 rounded border transition ${u.permissions.canEditProducts ? 'bg-green-100 border-green-300 text-green-800 font-bold' : 'bg-slate-50 border-slate-200 text-slate-400'}`}
                            title="تغییر دسترسی انبار"
                          >
                            تغییر انبار: {u.permissions.canEditProducts ? 'دارد' : 'ندارد'}
                          </button>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="flex flex-wrap gap-2 items-center">
                    {/* درخواست فراموشی رمز */}
                    {u.passwordResetRequested && (
                      <div className="flex gap-2 items-center bg-red-50 p-2 rounded-xl border border-red-200">
                        <span className="text-xs text-red-600 font-bold animate-pulse">درخواست ریست رمز</span>
                        <button onClick={() => onResetPassword(u.id)} className="bg-green-600 text-white px-3 py-1 rounded text-xs font-bold">تایید</button>
                        <button onClick={() => onDenyResetPassword(u.id)} className="bg-slate-200 text-slate-600 px-3 py-1 rounded text-xs">رد</button>
                      </div>
                    )}

                    {/* دکمه‌های مدیریت ویرایش، حذف و ریست بدون درخواست */}
                    {!editingUserId && (
                      <div className="flex items-center gap-1">
                        <button 
                          onClick={() => {
                            setEditingUserId(u.id);
                            setEditFullName(u.fullName);
                            setEditUsername(u.username);
                          }} 
                          className="bg-indigo-50 text-indigo-600 hover:bg-indigo-100 px-2.5 py-1.5 rounded text-xs font-bold"
                        >
                          ویرایش
                        </button>
                        
                        {u.id !== '1' && (
                          <button 
                            onClick={() => onDeleteUser(u.id)} 
                            className="bg-red-50 text-red-600 hover:bg-red-100 px-2.5 py-1.5 rounded text-xs font-bold"
                          >
                            حذف
                          </button>
                        )}
                        
                        <button 
                          onClick={() => {
                            if (confirm(`آیا از بازنشانی رمز کاربری @${u.username} به رمز اولیه (${u.initialPassword}) مطمئن هستید؟`)) {
                              onResetPassword(u.id);
                              alert(`رمز عبور با موفقیت به "${u.initialPassword}" بازگردانی شد.`);
                            }
                          }} 
                          className="bg-orange-50 text-orange-600 hover:bg-orange-100 px-2.5 py-1.5 rounded text-xs font-bold"
                        >
                          بازنشانی رمز
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Settings */}
      {activeTab === 'settings' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-sm font-vazir">
          <div className="bg-white p-6 rounded-2xl border">
            <h3 className="text-lg font-bold mb-4">اطلاعات فروشگاه</h3>
            <form onSubmit={handleSettingsSubmit} className="space-y-4">
              <div><label className="block mb-1">نام فروشگاه</label><input type="text" className="w-full px-3 py-2 border rounded-lg focus:ring-0" value={shopName} onChange={(e) => setShopName(e.target.value)} required /></div>
              <div><label className="block mb-1">آدرس فروشگاه</label><input type="text" className="w-full px-3 py-2 border rounded-lg focus:ring-0" value={shopAddress} onChange={(e) => setShopAddress(e.target.value)} /></div>
              <div><label className="block mb-1">شماره تماس</label><input type="text" className="w-full px-3 py-2 border rounded-lg focus:ring-0" value={shopPhone} onChange={(e) => setShopPhone(e.target.value)} /></div>
              <div>
                <label className="block mb-1">تم رنگی سایت</label>
                <select className="w-full px-3 py-2 border rounded-lg" value={shopTheme} onChange={(e) => setShopTheme(e.target.value as any)}>
                  <option value="violet">بنفش کلاسیک</option>
                  <option value="emerald">سبز زمردی</option>
                  <option value="gold">طلایی مجلل</option>
                  <option value="rose">صورتی گلدار</option>
                  <option value="ocean">آبی اقیانوسی</option>
                  <option value="dark">تیره مدرن</option>
                </select>
              </div>
              <button type="submit" className={`w-full ${themeStyle.primary} py-2 rounded-lg text-white font-bold`}>بروزرسانی تنظیمات</button>
            </form>
          </div>

          <div className="bg-white p-6 rounded-2xl border flex flex-col justify-between">
            <div>
              <h3 className="text-lg font-bold mb-4 text-slate-800 flex items-center gap-1"><Database className="text-indigo-600" /> بکاپ دیتابیس</h3>
              <p className="text-slate-500 text-xs mb-4 leading-relaxed">شما می‌توانید با دانلود فایل خروجی، امنیت اطلاعات مالی خود را تضمین کنید.</p>
              <button onClick={handleBackupDownload} className="flex items-center justify-center gap-2 w-full border border-indigo-600 text-indigo-600 py-2.5 rounded-lg hover:bg-indigo-50 font-bold mb-4"><Database className="w-4 h-4" /> پشتیبان‌گیری و دانلود بکاپ (.json)</button>
              <div className="border-t pt-4">
                <label className="block text-slate-700 font-bold mb-2">بازگردانی از فایل بکاپ:</label>
                <input type="file" accept=".json" onChange={handleBackupUpload} className="text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-slate-100 file:text-indigo-700 hover:file:bg-indigo-50" />
              </div>
            </div>

            <div className="border-t border-red-100 pt-6 mt-6">
              <h4 className="text-sm font-bold text-red-600 flex items-center gap-1 mb-2"><ShieldAlert className="w-5 h-5" /> پاکسازی کامل پایگاه داده</h4>
              <button onClick={onResetDatabase} className="w-full bg-red-600 hover:bg-red-700 text-white py-2.5 rounded-lg text-sm font-bold">حذف همه رکوردها</button>
            </div>
          </div>
        </div>
      )}

      {activeInvoice && <InvoiceModal sale={activeInvoice} onClose={() => setActiveInvoice(null)} settings={settings} />}
    </div>
  );
};
