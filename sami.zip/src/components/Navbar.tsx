import React from 'react';
import { User, ShopSettings } from '../types';
import { LogOut, User as UserIcon, Bell, Store, RefreshCw, Wifi, WifiOff } from 'lucide-react';

interface NavbarProps {
  user: User;
  settings: ShopSettings;
  onLogout: () => void;
  lowStockCount: number;
  isOnline: boolean;
  isSyncing: boolean;
  onSync: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  user, 
  settings, 
  onLogout, 
  lowStockCount,
  isOnline,
  isSyncing,
  onSync
}) => {
  const getThemeColor = () => {
    switch (settings.theme) {
      case 'emerald': return 'bg-emerald-800';
      case 'gold': return 'bg-amber-800';
      case 'rose': return 'bg-rose-800';
      case 'ocean': return 'bg-sky-800';
      case 'dark': return 'bg-slate-900';
      default: return 'bg-indigo-900';
    }
  };

  return (
    <nav className={`${getThemeColor()} text-white shadow-md font-vazir`} dir="rtl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <Store className="w-6 h-6 text-slate-200" />
            <span className="text-xl font-black tracking-wider">{settings.shopName || 'سیستم دیتابیس رخت'}</span>
            {user.role === 'admin' ? (
              <span className="bg-red-500/30 text-red-100 text-xs px-2.5 py-1 rounded-full font-bold">مدیر سیستم</span>
            ) : (
              <span className="bg-green-500/30 text-green-100 text-xs px-2.5 py-1 rounded-full font-bold">کارمند فروش</span>
            )}
          </div>

          <div className="flex items-center gap-4">
            {lowStockCount > 0 && (
              <div className="relative p-1.5 bg-white/10 rounded-lg text-yellow-300 border border-yellow-500/20 flex items-center gap-1 text-sm">
                <Bell className="w-5 h-5 animate-pulse" />
                <span className="font-bold">{lowStockCount} هشدار متراژ</span>
              </div>
            )}

            <div className="flex items-center gap-4 border-l border-white/10 pl-4">
              {/* Online/Offline Status */}
              <div className="flex items-center gap-1.5 px-2.5 py-1.5 bg-white/10 rounded-lg border border-white/10 text-xs font-medium">
                {isOnline ? (
                  <>
                    <Wifi className="w-4 h-4 text-green-400" />
                    <span className="text-green-400 font-bold">آنلاین</span>
                  </>
                ) : (
                  <>
                    <WifiOff className="w-4 h-4 text-amber-400" />
                    <span className="text-amber-400 font-bold">آفلاین</span>
                  </>
                )}
              </div>

              {/* Sync Button */}
              <button
                onClick={onSync}
                disabled={isSyncing}
                className={`flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600/60 hover:bg-indigo-600 border border-indigo-400/20 rounded-lg transition text-xs font-medium text-white shadow-inner ${
                  isSyncing ? 'opacity-70' : ''
                }`}
                title="همگام‌سازی اطلاعات محلی با دیتابیس ابری"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                {isSyncing ? 'درحال همگام‌سازی...' : 'همگام‌سازی'}
              </button>
            </div>

            <div className="flex items-center gap-2 text-slate-100 pr-2">
              <UserIcon className="w-5 h-5 text-white/70" />
              <span className="text-sm font-medium">{user.fullName}</span>
            </div>

            <button
              onClick={onLogout}
              className="flex items-center gap-1 px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-lg transition text-sm font-medium shadow-sm"
            >
              <LogOut className="w-4 h-4" />
              خروج
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};