import React, { useState } from 'react';
import { User } from '../types';
import { KeyRound, User as UserIcon, AlertCircle, HelpCircle } from 'lucide-react';

interface LoginProps {
  users: User[];
  onLogin: (user: User) => void;
  onRequestReset: (username: string) => void;
}

export const Login: React.FC<LoginProps> = ({ users, onLogin, onRequestReset }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [forgotMode, setForgotMode] = useState(false);
  const [resetUsername, setResetUsername] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const user = users.find(
      (u) => u.username === username && u.passwordHash === password
    );

    if (user) {
      onLogin(user);
    } else {
      setError('نام کاربری یا رمز عبور اشتباه است!');
    }
  };

  const handleResetSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMsg('');
    setError('');

    if (!resetUsername.trim()) {
      setError('لطفاً نام کاربری را وارد کنید.');
      return;
    }

    const userExists = users.find((u) => u.username === resetUsername);
    if (!userExists) {
      setError('کاربری با این نام پیدا نشد!');
      return;
    }

    onRequestReset(resetUsername);
    setSuccessMsg('درخواست بازیابی رمز به ادمین ارسال شد. ادمین می‌تواند رمز شما را ریست کند.');
    setTimeout(() => {
      setForgotMode(false);
      setResetUsername('');
      setSuccessMsg('');
    }, 3000);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 font-vazir" dir="rtl">
      <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md border border-slate-100">
        <div className="text-center mb-8">
          <div className="bg-indigo-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <KeyRound className="w-8 h-8 text-indigo-600" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800">سیستم دیتابیس رخت فروشی</h2>
          <p className="text-slate-500 text-sm mt-2">مدیریت محصولات، فاکتورها و برداشت‌ها</p>
        </div>

        {error && (
          <div className="mb-4 bg-red-50 text-red-600 p-3 rounded-lg flex items-center gap-2 text-sm">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {successMsg && (
          <div className="mb-4 bg-green-50 text-green-600 p-3 rounded-lg flex items-center gap-2 text-sm font-bold">
            <span>{successMsg}</span>
          </div>
        )}

        {!forgotMode ? (
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-slate-700 font-medium mb-1.5">نام کاربری</label>
              <div className="relative">
                <input
                  type="text"
                  className="w-full pl-3 pr-10 py-2.5 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white text-right"
                  placeholder="نام کاربری خود را وارد کنید"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                />
                <UserIcon className="w-5 h-5 text-slate-400 absolute top-3 right-3" />
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-medium mb-1.5">رمز عبور</label>
              <div className="relative">
                <input
                  type="password"
                  className="w-full pl-3 pr-10 py-2.5 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white text-right"
                  placeholder="رمز عبور خود را وارد کنید"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <KeyRound className="w-5 h-5 text-slate-400 absolute top-3 right-3" />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 text-white py-2.5 rounded-lg hover:bg-indigo-700 transition duration-200 font-medium shadow-md shadow-indigo-200"
            >
              ورود به سیستم
            </button>

            <div className="text-center mt-4">
              <button
                type="button"
                onClick={() => setForgotMode(true)}
                className="text-indigo-600 hover:underline text-sm flex items-center justify-center gap-1 mx-auto"
              >
                <HelpCircle className="w-4 h-4" />
                رمز عبور خود را فراموش کرده‌اید؟
              </button>
            </div>
          </form>
        ) : (
          <form onSubmit={handleResetSubmit} className="space-y-5">
            <h3 className="text-lg font-bold text-slate-800 text-center mb-2">درخواست بازیابی رمز عبور</h3>
            <p className="text-slate-500 text-xs text-center leading-relaxed">
              نام کاربری خود را وارد کنید تا به ادمین پیام داده شود و رمز اولیه شما بازگردد.
            </p>

            <div>
              <label className="block text-slate-700 font-medium mb-1.5">نام کاربری</label>
              <div className="relative">
                <input
                  type="text"
                  className="w-full pl-3 pr-10 py-2.5 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white text-right"
                  placeholder="نام کاربری شما"
                  value={resetUsername}
                  onChange={(e) => setResetUsername(e.target.value)}
                  required
                />
                <UserIcon className="w-5 h-5 text-slate-400 absolute top-3 right-3" />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 text-white py-2.5 rounded-lg hover:bg-indigo-700 transition duration-200 font-medium"
            >
              ارسال درخواست به ادمین
            </button>

            <div className="text-center mt-4">
              <button
                type="button"
                onClick={() => setForgotMode(false)}
                className="text-slate-500 hover:underline text-sm"
              >
                بازگشت به ورود
              </button>
            </div>
          </form>
        )}

        {/* Mobile Application Download Section */}
        <div className="mt-8 pt-6 border-t border-slate-100 text-center">
          <p className="text-xs text-slate-400 font-medium mb-3">دسترسی سریع از طریق اپلیکیشن موبایل</p>
          <div className="flex justify-center gap-3">
            {/* Android Button */}
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                alert('فایل APK برای انتشار در پلی استور آماده است. برای پکیج نهایی Capacitor و تولید APK درخواست خروجی بزنید.');
              }}
              className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl transition duration-200 shadow-sm text-xs border border-slate-700 w-1/2 justify-center"
            >
              <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-green-400">
                <path d="M3.25 15.15v2.85l2.85-2.85h-2.85zM17.9 6.2C17.2 4.9 15.8 4 14.1 4H9.9c-1.7 0-3.1.9-3.8 2.2L12 12.3l5.9-6.1zM14.1 20c1.7 0 3.1-.9 3.8-2.2L12 11.7l-5.9 6.1c.7 1.3 2.1 2.2 3.8 2.2h4.2zM20.75 15.15l-2.85 2.85h2.85v-2.85zM21.2 8.4l-6.2 6.2 6.2 6.2c.5-.6.8-1.4.8-2.3V10.7c0-.9-.3-1.7-.8-2.3zM2.8 8.4C2.3 9 .2 9.8.2 10.7v5.6c0 .9.3 1.7.8 2.3l6.2-6.2-6.2-6.2z"/>
              </svg>
              <div className="text-right">
                <span className="block text-[10px] text-slate-400 leading-3">دریافت نسخه</span>
                <span className="font-bold text-sm">Android</span>
              </div>
            </a>

            {/* iOS Button */}
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                alert('نسخه iOS آماده است. با ساخت PWA یا انتشار در اپ استور برای آیفون استفاده می‌شود.');
              }}
              className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl transition duration-200 shadow-sm text-xs border border-slate-700 w-1/2 justify-center"
            >
              <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-slate-200">
                <path d="M18.71,19.5 C17.88,20.74 17,21.95 15.66,21.97 C14.32,22 13.89,21.18 12.37,21.18 C10.84,21.18 10.37,21.95 9.1,22 C7.79,22.05 6.8,20.68 5.96,19.47 C4.25,17 2.94,12.45 4.7,9.39 C5.57,7.87 7.13,6.91 8.82,6.88 C10.1,6.86 11.32,7.75 12.11,7.75 C12.89,7.75 14.37,6.68 15.92,6.84 C16.57,6.87 18.39,7.1 19.56,8.82 C19.47,8.88 17.39,10.1 17.41,12.63 C17.44,15.65 20.06,16.66 20.1,16.67 C20.08,16.74 19.67,18.11 18.71,19.5 M15.97,4.17 C16.63,3.37 17.07,2.26 16.95,1.14 C16,1.18 14.9,1.75 14.25,2.51 C13.68,3.18 13.19,4.31 13.35,5.4 C14.39,5.48 15.39,4.88 15.97,4.17"/>
              </svg>
              <div className="text-right">
                <span className="block text-[10px] text-slate-400 leading-3">دریافت نسخه</span>
                <span className="font-bold text-sm">iOS</span>
              </div>
            </a>
          </div>
        </div>

      </div>
    </div>
  );
};
