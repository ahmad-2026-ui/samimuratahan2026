import { useState, useEffect } from 'react';
import { User, Product, Sale, Expense, Withdrawal, FabricType, ShopSettings, UserPermissions } from './types';
import { Navbar } from './components/Navbar';
import { Login } from './components/Login';
import { AdminDashboard } from './components/AdminDashboard';
import { StaffDashboard } from './components/StaffDashboard';

const initialUsers: User[] = [
  {
    id: '1',
    username: 'admin',
    fullName: 'مدیر کل فروشگاه',
    role: 'admin',
    passwordHash: 'admin123',
    initialPassword: 'admin123',
    passwordResetRequested: false,
    permissions: { canAddReceipt: true, canDeleteTransactions: true, canEditProducts: true }
  }
];

const initialFabricTypes: FabricType[] = [
  { id: 'f1', name: 'نخی' },
  { id: 'f2', name: 'کتان' },
  { id: 'f3', name: 'حریر' },
  { id: 'f4', name: 'مخمل' }
];

const defaultSettings: ShopSettings = {
  shopName: 'فروشگاه رخت برتر',
  address: 'جاده مرکزی، دکان شماره ۲۳',
  phone: '۰۷۸۹۱۲۳۴۵۶',
  theme: 'violet'
};

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>(initialUsers);
  const [fabricTypes, setFabricTypes] = useState<FabricType[]>(initialFabricTypes);
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [settings, setSettings] = useState<ShopSettings>(defaultSettings);

  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleSync = () => {
    setIsSyncing(true);
    // شبیه‌سازی همگام‌سازی ابری امن دیتابیس
    setTimeout(() => {
      setIsSyncing(false);
      alert('تمامی داده‌ها با موفقیت با فضای ابری هاست (Host) همگام‌سازی (Sync) شدند.');
    }, 1500);
  };

  useEffect(() => {
    const localUsers = localStorage.getItem('cloth_users');
    const localFabricTypes = localStorage.getItem('cloth_fabrics');
    const localProducts = localStorage.getItem('cloth_products');
    const localSales = localStorage.getItem('cloth_sales');
    const localExpenses = localStorage.getItem('cloth_expenses');
    const localWithdrawals = localStorage.getItem('cloth_withdrawals');
    const localSettings = localStorage.getItem('cloth_settings');

    if (localUsers) setUsers(JSON.parse(localUsers));
    if (localFabricTypes) setFabricTypes(JSON.parse(localFabricTypes));
    if (localProducts) setProducts(JSON.parse(localProducts));
    if (localSales) setSales(JSON.parse(localSales));
    if (localExpenses) setExpenses(JSON.parse(localExpenses));
    if (localWithdrawals) setWithdrawals(JSON.parse(localWithdrawals));
    if (localSettings) setSettings(JSON.parse(localSettings));
  }, []);

  useEffect(() => {
    const handleStorage = (e: StorageEvent) => {
      try {
        if (e.key === 'cloth_users' && e.newValue) setUsers(JSON.parse(e.newValue));
        if (e.key === 'cloth_fabrics' && e.newValue) setFabricTypes(JSON.parse(e.newValue));
        if (e.key === 'cloth_products' && e.newValue) setProducts(JSON.parse(e.newValue));
        if (e.key === 'cloth_sales' && e.newValue) setSales(JSON.parse(e.newValue));
        if (e.key === 'cloth_expenses' && e.newValue) setExpenses(JSON.parse(e.newValue));
        if (e.key === 'cloth_withdrawals' && e.newValue) setWithdrawals(JSON.parse(e.newValue));
        if (e.key === 'cloth_settings' && e.newValue) setSettings(JSON.parse(e.newValue));
      } catch (err) {
        console.error(err);
      }
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  const saveToLocal = (key: string, data: any) => {
    localStorage.setItem(key, JSON.stringify(data));
    window.dispatchEvent(new Event('storage'));
  };

  const handleLogin = (user: User) => setCurrentUser(user);
  const handleLogout = () => setCurrentUser(null);

  const handleRequestReset = (username: string) => {
    const updated = users.map(u => u.username === username ? { ...u, passwordResetRequested: true } : u);
    setUsers(updated);
    saveToLocal('cloth_users', updated);
  };

  const handleResetPassword = (userId: string) => {
    const updated = users.map(u => u.id === userId ? { ...u, passwordHash: u.initialPassword, passwordResetRequested: false } : u);
    setUsers(updated);
    saveToLocal('cloth_users', updated);
  };

  const handleDenyResetPassword = (userId: string) => {
    const updated = users.map(u => u.id === userId ? { ...u, passwordResetRequested: false } : u);
    setUsers(updated);
    saveToLocal('cloth_users', updated);
  };

  const handleAddProduct = (pData: Omit<Product, 'id' | 'createdAt' | 'remainingMeters' | 'purchasePricePerMeter'>) => {
    const purchasePricePerMeter = pData.totalPurchasePrice / pData.totalMeters;
    const newProduct: Product = {
      ...pData,
      id: 'prod_' + Math.random().toString(36).substr(2, 9),
      remainingMeters: pData.totalMeters,
      purchasePricePerMeter,
      createdAt: new Date().toISOString()
    };
    const updated = [newProduct, ...products];
    setProducts(updated);
    saveToLocal('cloth_products', updated);
  };

  const handleDeleteProduct = (id: string) => {
    const updated = products.filter(p => p.id !== id);
    setProducts(updated);
    saveToLocal('cloth_products', updated);
  };

  const handleAddFabricType = (name: string) => {
    const newType: FabricType = { id: 'fab_' + Math.random().toString(36).substr(2, 9), name };
    const updated = [...fabricTypes, newType];
    setFabricTypes(updated);
    saveToLocal('cloth_fabrics', updated);
  };

  const handleAddExpense = (eData: Omit<Expense, 'id' | 'createdAt'>) => {
    const newExp: Expense = { ...eData, id: 'exp_' + Math.random().toString(36).substr(2, 9), createdAt: new Date().toISOString() };
    const updated = [newExp, ...expenses];
    setExpenses(updated);
    saveToLocal('cloth_expenses', updated);
  };

  const handleDeleteExpense = (id: string) => {
    const updated = expenses.filter(e => e.id !== id);
    setExpenses(updated);
    saveToLocal('cloth_expenses', updated);
  };

  const handleAddWithdrawal = (wData: Omit<Withdrawal, 'id' | 'createdAt'>) => {
    const newWith: Withdrawal = { ...wData, id: 'with_' + Math.random().toString(36).substr(2, 9), createdAt: new Date().toISOString() };
    const updated = [newWith, ...withdrawals];
    setWithdrawals(updated);
    saveToLocal('cloth_withdrawals', updated);
  };

  const handleDeleteWithdrawal = (id: string) => {
    const updated = withdrawals.filter(w => w.id !== id);
    setWithdrawals(updated);
    saveToLocal('cloth_withdrawals', updated);
  };

  const handleAddSale = (sData: Omit<Sale, 'id' | 'createdAt' | 'staffId' | 'staffName'>) => {
    if (!currentUser) return;
    const newSale: Sale = {
      ...sData,
      id: 'sale_' + Math.random().toString(36).substr(2, 9),
      staffId: currentUser.id,
      staffName: currentUser.fullName,
      createdAt: new Date().toISOString()
    };
    const updatedProducts = products.map(prod => {
      const itemSold = sData.items.find(item => item.productId === prod.id);
      if (itemSold) return { ...prod, remainingMeters: Math.max(0, prod.remainingMeters - itemSold.metersSold) };
      return prod;
    });
    const updatedSales = [newSale, ...sales];
    setSales(updatedSales);
    setProducts(updatedProducts);
    saveToLocal('cloth_sales', updatedSales);
    saveToLocal('cloth_products', updatedProducts);
  };

  const handleDeleteSale = (saleId: string) => {
    const targetSale = sales.find(s => s.id === saleId);
    if (!targetSale) return;

    const updatedProducts = products.map(prod => {
      const soldItem = targetSale.items.find(item => item.productId === prod.id);
      if (soldItem) return { ...prod, remainingMeters: prod.remainingMeters + soldItem.metersSold };
      return prod;
    });

    const updatedSales = sales.filter(s => s.id !== saleId);
    setSales(updatedSales);
    setProducts(updatedProducts);
    saveToLocal('cloth_sales', updatedSales);
    saveToLocal('cloth_products', updatedProducts);
  };

  const handleUpdateSettings = (newSettings: ShopSettings) => {
    setSettings(newSettings);
    saveToLocal('cloth_settings', newSettings);
  };

  const handleCreateUser = (fullName: string, username: string, role: 'admin' | 'staff', initialPass: string, permissions: UserPermissions) => {
    const newUser: User = {
      id: 'user_' + Math.random().toString(36).substr(2, 9),
      fullName,
      username,
      role,
      passwordHash: initialPass,
      initialPassword: initialPass,
      passwordResetRequested: false,
      permissions
    };
    const updated = [...users, newUser];
    setUsers(updated);
    saveToLocal('cloth_users', updated);
  };

  const handleUpdateUserPermissions = (userId: string, permissions: UserPermissions) => {
    const updated = users.map(u => u.id === userId ? { ...u, permissions } : u);
    setUsers(updated);
    saveToLocal('cloth_users', updated);
  };

  const handleDeleteUser = (userId: string) => {
    if (userId === '1') {
      alert('حساب کاربری ادمین اصلی قابل حذف نیست!');
      return;
    }
    if (confirm('آیا از حذف این کارمند اطمینان دارید؟')) {
      const updated = users.filter(u => u.id !== userId);
      setUsers(updated);
      saveToLocal('cloth_users', updated);
    }
  };

  const handleUpdateUser = (userId: string, fullName: string, username: string) => {
    const updated = users.map(u => u.id === userId ? { ...u, fullName, username } : u);
    setUsers(updated);
    saveToLocal('cloth_users', updated);
  };

  const handleResetDatabase = () => {
    localStorage.clear();
    setUsers(initialUsers);
    setFabricTypes(initialFabricTypes);
    setProducts([]);
    setSales([]);
    setExpenses([]);
    setWithdrawals([]);
    setSettings(defaultSettings);
    alert('تمام اطلاعات دیتابیس با موفقیت پاکسازی شد.');
  };

  const lowStockCount = products.filter(p => p.remainingMeters <= 20).length;

  if (!currentUser) {
    return (
      <Login
        users={users}
        onLogin={handleLogin}
        onRequestReset={handleRequestReset}
      />
    );
  }

  return (
    <div className={`min-h-screen flex flex-col font-vazir`} dir="rtl">
      <Navbar
        user={currentUser}
        settings={settings}
        onLogout={handleLogout}
        lowStockCount={lowStockCount}
        isOnline={isOnline}
        isSyncing={isSyncing}
        onSync={handleSync}
      />

      <main className="flex-1">
        {currentUser.role === 'admin' ? (
          <AdminDashboard
            products={products}
            sales={sales}
            expenses={expenses}
            withdrawals={withdrawals}
            users={users}
            fabricTypes={fabricTypes}
            settings={settings}
            onAddProduct={handleAddProduct}
            onDeleteProduct={handleDeleteProduct}
            onAddExpense={handleAddExpense}
            onDeleteExpense={handleDeleteExpense}
            onAddWithdrawal={handleAddWithdrawal}
            onDeleteWithdrawal={handleDeleteWithdrawal}
            onAddFabricType={handleAddFabricType}
            onResetPassword={handleResetPassword}
            onDenyResetPassword={handleDenyResetPassword}
            onUpdateSettings={handleUpdateSettings}
            onCreateUser={handleCreateUser}
            onUpdateUserPermissions={handleUpdateUserPermissions}
            onResetDatabase={handleResetDatabase}
            onAddSale={handleAddSale}
            onDeleteSale={handleDeleteSale}
            onDeleteUser={handleDeleteUser}
            onUpdateUser={handleUpdateUser}
          />
        ) : (
          <StaffDashboard
            products={products}
            sales={sales}
            currentStaffId={currentUser.id}
            settings={settings}
            users={users}
            onAddSale={handleAddSale}
            onDeleteSale={handleDeleteSale}
          />
        )}
      </main>
    </div>
  );
}
