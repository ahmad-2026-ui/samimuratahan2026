import { useState } from 'react';
import { useStore } from '../store/useStore';
import { Plus, Trash2, Search, Wallet, ArrowDownRight, ArrowUpLeft, AlertCircle } from 'lucide-react';

export default function Withdrawals() {
  const { withdrawals, addWithdrawal, deleteWithdrawal, currentUser } = useStore();
  const isAdmin = currentUser?.role === 'admin';

  const [showModal, setShowModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState({
    personName: '',
    amount: 0,
    type: 'withdrawal' as 'withdrawal' | 'repayment',
    description: '',
    date: new Date().toISOString().split('T')[0],
  });

  const filteredWithdrawals = withdrawals.filter(
    (w) =>
      w.personName.includes(searchTerm) ||
      w.description.includes(searchTerm)
  );

  // محاسبه مجموع برای هر شخص
  const peopleSummary = withdrawals.reduce((acc, curr) => {
    if (!acc[curr.personName]) {
      acc[curr.personName] = { totalWithdrawal: 0, totalRepayment: 0 };
    }
    if (curr.type === 'withdrawal') {
      acc[curr.personName].totalWithdrawal += curr.amount;
    } else {
      acc[curr.personName].totalRepayment += curr.amount;
    }
    return acc;
  }, {} as Record<string, { totalWithdrawal: number; totalRepayment: number }>);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addWithdrawal(formData);
    setShowModal(false);
    setFormData({
      personName: '',
      amount: 0,
      type: 'withdrawal',
      description: '',
      date: new Date().toISOString().split('T')[0],
    });
  };

  const handleDelete = (id: string) => {
    if (confirm('آیا مطمئن هستید؟')) {
      deleteWithdrawal(id);
    }
  };

  return (
    <div className="space-y-6">
      {/* آمار برداشت‌ها */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl shadow-sm p-6 border-r-4 border-red-500">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-red-100 text-red-600 rounded-lg">
              <ArrowUpLeft size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-500">مجموع برداشت‌ها</p>
              <h3 className="text-2xl font-bold text-gray-800">
                {withdrawals
                  .filter((w) => w.type === 'withdrawal')
                  .reduce((sum, w) => sum + w.amount, 0)
                  .toLocaleString()}{' '}
                ؋
              </h3>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border-r-4 border-green-500">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-green-100 text-green-600 rounded-lg">
              <ArrowDownRight size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-500">مجموع بازپرداخت‌ها</p>
              <h3 className="text-2xl font-bold text-gray-800">
                {withdrawals
                  .filter((w) => w.type === 'repayment')
                  .reduce((sum, w) => sum + w.amount, 0)
                  .toLocaleString()}{' '}
                ؋
              </h3>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border-r-4 border-blue-500">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-blue-100 text-blue-600 rounded-lg">
              <Wallet size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-500">باقی‌مانده بدهی اشخاص</p>
              <h3 className="text-2xl font-bold text-gray-800">
                {(
                  withdrawals
                    .filter((w) => w.type === 'withdrawal')
                    .reduce((sum, w) => sum + w.amount, 0) -
                  withdrawals
                    .filter((w) => w.type === 'repayment')
                    .reduce((sum, w) => sum + w.amount, 0)
                ).toLocaleString()}{' '}
                ؋
              </h3>
            </div>
          </div>
        </div>
      </div>

      {/* خلاصه حساب اشخاص */}
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h3 className="text-lg font-bold text-gray-800 mb-4">خلاصه حساب اشخاص</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Object.entries(peopleSummary).map(([name, summary]) => (
            <div key={name} className="p-4 bg-gray-50 rounded-lg border">
              <h4 className="font-bold text-gray-800 mb-2">{name}</h4>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">برداشت:</span>
                  <span className="text-red-600 font-medium">
                    {summary.totalWithdrawal.toLocaleString()} ؋
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">پرداخت:</span>
                  <span className="text-green-600 font-medium">
                    {summary.totalRepayment.toLocaleString()} ؋
                  </span>
                </div>
                <div className="flex justify-between border-t pt-1 mt-1 font-bold">
                  <span>مانده حساب:</span>
                  <span className={summary.totalWithdrawal - summary.totalRepayment > 0 ? 'text-red-600' : 'text-green-600'}>
                    {(summary.totalWithdrawal - summary.totalRepayment).toLocaleString()} ؋
                  </span>
                </div>
              </div>
            </div>
          ))}
          {Object.keys(peopleSummary).length === 0 && (
            <p className="text-gray-500 text-sm">هیچ اطلاعاتی ثبت نشده است.</p>
          )}
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <div className="relative flex-1 w-full sm:max-w-md">
          <Search
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
            size={20}
          />
          <input
            type="text"
            placeholder="جستجوی شخص یا توضیحات..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pr-10 pl-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
          />
        </div>
        {isAdmin && (
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition-colors"
          >
            <Plus size={20} />
            <span>ثبت تراکنش جدید</span>
          </button>
        )}
      </div>

      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b">
                <th className="px-6 py-3 text-sm font-semibold text-gray-600">شخص</th>
                <th className="px-6 py-3 text-sm font-semibold text-gray-600">نوع</th>
                <th className="px-6 py-3 text-sm font-semibold text-gray-600">مبلغ</th>
                <th className="px-6 py-3 text-sm font-semibold text-gray-600">تاریخ</th>
                <th className="px-6 py-3 text-sm font-semibold text-gray-600">توضیحات</th>
                {isAdmin && (
                  <th className="px-6 py-3 text-sm font-semibold text-gray-600">عملیات</th>
                )}
              </tr>
            </thead>
            <tbody className="divide-y">
              {filteredWithdrawals.map((w) => (
                <tr key={w.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm font-medium text-gray-800">
                    {w.personName}
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <span
                      className={`px-2 py-1 rounded-full text-xs ${
                        w.type === 'withdrawal'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-green-100 text-green-800'
                      }`}
                    >
                      {w.type === 'withdrawal' ? 'برداشت' : 'بازپرداخت'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm font-medium text-gray-800">
                    {w.amount.toLocaleString()} ؋
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">
                    {new Date(w.date).toLocaleDateString('fa-IR')}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    {w.description || '---'}
                  </td>
                  {isAdmin && (
                    <td className="px-6 py-4 text-sm">
                      <button
                        onClick={() => handleDelete(w.id)}
                        className="text-red-500 hover:text-red-700 p-1"
                        title="حذف"
                      >
                        <Trash2 size={18} />
                      </button>
                    </td>
                  )}
                </tr>
              ))}
              {filteredWithdrawals.length === 0 && (
                <tr>
                  <td
                    colSpan={isAdmin ? 6 : 5}
                    className="px-6 py-8 text-center text-gray-500"
                  >
                    <AlertCircle size={48} className="mx-auto text-gray-300 mb-2" />
                    هیچ تراکنشی یافت نشد
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl w-full max-w-md">
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="text-lg font-bold text-gray-800">تراکنش جدید</h3>
              <button
                onClick={() => setShowModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-4 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  نام شخص (برادر، پدر، ادمین و...)
                </label>
                <input
                  type="text"
                  value={formData.personName}
                  onChange={(e) =>
                    setFormData({ ...formData, personName: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  نوع تراکنش
                </label>
                <select
                  value={formData.type}
                  onChange={(e) =>
                    setFormData({ ...formData, type: e.target.value as any })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  required
                >
                  <option value="withdrawal">برداشت از صندوق</option>
                  <option value="repayment">بازپرداخت به صندوق</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  مبلغ (؋)
                </label>
                <input
                  type="number"
                  value={formData.amount}
                  onChange={(e) =>
                    setFormData({ ...formData, amount: Number(e.target.value) })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  required
                  min="0"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  تاریخ
                </label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) =>
                    setFormData({ ...formData, date: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  توضیحات
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) =>
                    setFormData({ ...formData, description: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  rows={3}
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded-lg transition-colors"
                >
                  ثبت تراکنش
                </button>
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-2 rounded-lg transition-colors"
                >
                  انصراف
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}